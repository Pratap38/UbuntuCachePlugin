import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';

export default class RamGuardianFocusExtension {

    constructor() {
        this.focusChangedId = null;
        this.pollSourceId = null;
    }

    enable() {

        console.log(
            '[RAM Guardian] Focus tracker extension enabled'
        );

        /*
         * GNOME Shell's display object manages
         * the currently focused window.
         */
        this.display = global.display;

        /*
         * Listen for focus changes.
         */
        this.focusChangedId = this.display.connect(
            'notify::focus-window',
            () => {

                this.handleFocusChange();

            }
        );

        /*
         * Detect the current focus immediately.
         */
        this.handleFocusChange();
    }

    disable() {

        if (this.focusChangedId !== null) {

            this.display.disconnect(
                this.focusChangedId
            );

            this.focusChangedId = null;
        }

        console.log(
            '[RAM Guardian] Focus tracker extension disabled'
        );
    }

    handleFocusChange() {

        const window = this.display.get_focus_window();

        if (!window) {

            console.log(
                '[RAM Guardian] No focused window'
            );

            return;
        }

        const application = this.getApplication(
            window
        );

        const windowInfo = {

            window_id:
                window.get_id(),

            title:
                window.get_title() || '',

            application:
                application,

            pid:
                window.get_pid(),

            focused:
                true,

            timestamp:
                GLib.get_real_time()
        };

        console.log(
            '[RAM Guardian] Focus changed:',
            JSON.stringify(windowInfo)
        );
    }

    getApplication(window) {

        try {

            const tracker =
                Shell.WindowTracker.get_default();

            const app =
                tracker.get_window_app(window);

            if (app) {

                return app.get_name();
            }

        } catch (error) {

            console.error(
                '[RAM Guardian] Application lookup failed:',
                error
            );
        }

        return 'Unknown';
    }
}